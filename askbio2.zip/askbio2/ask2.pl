my $fasta_file = 'ask2.txt';
open(my $fh, '<', $fasta_file) or die "Can't open file: $!";



    if ($line =~ /^[ATCG]+$/i) {
        print "Μη έγκυρη αλληλουχία\n";
    } else {
        print "Έγκυρη\n";
    }


close($fh);