$sequence = "MNVEHE _123! LLVEE \$";

my @amino_acids = ($sequence =~ /[A-Z]/g);

my $clean_sequence = join('', @amino_acids);


print "Αμινοξέα: $clean_sequence\n";
