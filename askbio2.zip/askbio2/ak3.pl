
$sequence = "ATGCGATGGTATG";
$count = () = $sequence =~ /ATG/g;
print "Start codons found: $count\n";

