my $fasta_file = 'ask1.txt';  
open(my $fh, '<', $fasta_file) or die "Can't open file: $!";

while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /^>\w+\|([^|]+)/) {
        print "$1\n";  
    }
}

close($fh);